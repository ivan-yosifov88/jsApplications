const postUrl = 'http://localhost:3030/jsonstore/collections/myboard/posts';
const commentUrl = 'http://localhost:3030/jsonstore/collections/myboard';

let requestUrl = {
    postUrl,
    commentUrl
}

export default requestUrl